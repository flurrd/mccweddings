(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./data/config.json":
/*!**************************!*\
  !*** ./data/config.json ***!
  \**************************/
/*! exports provided: title, description, repositoryUrl, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"title\":\"Maureen Catherine Crawley's Portfolio | Developer | Digital Designer\",\"description\":\"The description\",\"repositoryUrl\":\"https://github.com/flurrd/portfolio2020\"}");

/***/ })

}]);
//# sourceMappingURL=2.js.map